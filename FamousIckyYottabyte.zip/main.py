import turtle
for i in range(6):
  for j in range(4):
    turtle.forward(100)
    turtle.left(90)
  turtle.right(60)
turtle.penup
for a in range(36):
  for b in range(6):
    turtle.forward(100)
    turtle.left(60)
  turtle.right(10)