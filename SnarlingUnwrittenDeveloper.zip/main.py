import turtle
boi0=turtle.Turtle()
boi1=turtle.Turtle()
boi2=turtle.Turtle()
color=('red', 'blue', 'green')
speed=(1,2,3)
boi0.color(color[0])
boi1.color(color[1])
boi2.color(color[2])
turtle_list=[boi0,boi1,boi2]
for e in range(3):
    turtle_list[e].color(color[e])
    turtle_list[e].penup()
    turtle_list[e].goto(-160, 100*e)
    turtle_list[e].pendown()
for movement in range(100):
    for e in range(3):            
        turtle_list[e].forward(speed[e])

